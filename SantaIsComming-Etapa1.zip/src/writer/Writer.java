package writer;

import java.util.ArrayList;
import java.util.List;

public final class Writer {
    private final List<ChildrenOutput> annualChildren = new ArrayList<>();

    public List<ChildrenOutput> getAnnaulChildren() {
        return annualChildren;
    }

}
